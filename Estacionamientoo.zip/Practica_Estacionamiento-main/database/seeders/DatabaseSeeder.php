<?php
namespace Database\Seeders;

use App\Models\{Celda, Tarifa, User};
use Illuminate\Database\Seeder;

/** Datos iniciales: 3 usuarios (uno por rol), tarifas y celdas de ejemplo. */
class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // La contraseña se hashea sola por el cast 'hashed' del modelo User
        User::create(['name' => 'Administrador', 'email' => 'admin@parking.com', 'password' => 'password', 'rol' => 'administrador']);
        User::create(['name' => 'Operador Caja', 'email' => 'operador@parking.com', 'password' => 'password', 'rol' => 'operador']);
        User::create(['name' => 'Supervisor', 'email' => 'supervisor@parking.com', 'password' => 'password', 'rol' => 'supervisor']);

        foreach (['auto' => 5, 'moto' => 2, 'camioneta' => 8] as $tipo => $precio) {
            Tarifa::create(['tipo_vehiculo' => $tipo, 'precio_hora' => $precio, 'fraccion_minutos' => 15]);
        }

        // 2 pisos x 2 sectores x 5 celdas
        foreach (['Piso 1', 'Piso 2'] as $i => $piso) {
            foreach (['A', 'B'] as $sector) {
                for ($n = 1; $n <= 5; $n++) {
                    Celda::create(['piso' => $piso, 'sector' => $sector, 'codigo' => 'P'.($i + 1)."-$sector$n"]);
                }
            }
        }
    }
}
