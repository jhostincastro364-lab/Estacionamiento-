<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Migración principal del sistema de estacionamiento.
 * IMPORTANTE: ningún registro se elimina; cada tabla tiene columna "estado"
 * (1 = activo, 0 = inactivo) para el borrado lógico.
 */
return new class extends Migration {
    public function up(): void
    {
        // Se amplía la tabla users que ya trae Laravel: rol y estado
        Schema::table('users', function (Blueprint $t) {
            $t->enum('rol', ['administrador', 'operador', 'supervisor'])->default('operador');
            $t->boolean('estado')->default(true);
        });

        // Clientes habituales / abonados (mensualidades y convenios)
        Schema::create('clientes', function (Blueprint $t) {
            $t->id();
            $t->string('nombre');
            $t->string('ci', 20)->nullable();
            $t->string('telefono', 20)->nullable();
            $t->string('email')->nullable();
            $t->enum('tipo', ['habitual', 'abonado'])->default('habitual');
            $t->string('convenio')->nullable();          // detalle del convenio
            $t->date('fecha_fin_abono')->nullable();     // vigencia de la mensualidad
            $t->boolean('estado')->default(true);
            $t->timestamps();
        });

        // Vehículos (pueden pertenecer a un cliente o ser visitantes)
        Schema::create('vehiculos', function (Blueprint $t) {
            $t->id();
            $t->foreignId('cliente_id')->nullable()->constrained('clientes');
            $t->string('placa', 15)->unique();
            $t->string('marca')->nullable();
            $t->string('modelo')->nullable();
            $t->string('color', 30)->nullable();
            $t->enum('tipo', ['auto', 'moto', 'camioneta'])->default('auto');
            $t->boolean('estado')->default(true);
            $t->timestamps();
        });

        // Celdas con su piso y sector; "ocupada" cambia en tiempo real con entradas/salidas
        Schema::create('celdas', function (Blueprint $t) {
            $t->id();
            $t->string('piso', 30);
            $t->string('sector', 30);
            $t->string('codigo', 20)->unique();
            $t->boolean('ocupada')->default(false);
            $t->boolean('estado')->default(true);
            $t->timestamps();
        });

        // Tarifa por tipo de vehículo: precio por hora y fracción de cobro (minutos)
        Schema::create('tarifas', function (Blueprint $t) {
            $t->id();
            $t->enum('tipo_vehiculo', ['auto', 'moto', 'camioneta'])->unique();
            $t->decimal('precio_hora', 8, 2);
            $t->unsignedSmallInteger('fraccion_minutos')->default(15);
            $t->boolean('estado')->default(true);
            $t->timestamps();
        });

        // Tickets: cada entrada/salida de un vehículo
        Schema::create('tickets', function (Blueprint $t) {
            $t->id();
            $t->string('codigo', 30)->unique();
            $t->foreignId('vehiculo_id')->constrained('vehiculos');
            $t->foreignId('celda_id')->constrained('celdas');
            $t->foreignId('user_id')->constrained('users');   // operador que registró la entrada
            $t->dateTime('entrada');
            $t->dateTime('salida')->nullable();
            $t->unsignedInteger('minutos')->nullable();
            $t->decimal('monto', 10, 2)->nullable();
            $t->enum('estado', ['en_curso', 'cobrado'])->default('en_curso');
            $t->timestamps();
        });

        // Pagos (caja): efectivo o QR
        Schema::create('pagos', function (Blueprint $t) {
            $t->id();
            $t->foreignId('ticket_id')->constrained('tickets');
            $t->foreignId('user_id')->constrained('users');   // cajero
            $t->decimal('monto', 10, 2);
            $t->enum('metodo', ['efectivo', 'qr']);
            $t->string('referencia')->nullable();             // nro. de transacción QR
            $t->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('pagos');
        Schema::dropIfExists('tickets');
        Schema::dropIfExists('tarifas');
        Schema::dropIfExists('celdas');
        Schema::dropIfExists('vehiculos');
        Schema::dropIfExists('clientes');
        Schema::table('users', fn (Blueprint $t) => $t->dropColumn(['rol', 'estado']));
    }
};
