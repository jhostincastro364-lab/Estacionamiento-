@extends('layouts.app')
@section('titulo', 'Vehículos')
@section('contenido')
<div class="card">
  <div class="card-header"><button id="btn-nuevo" class="btn btn-primary"><i class="bi bi-plus-lg"></i> Nuevo vehículo</button></div>
  <div class="card-body">
    <table id="tabla" class="table table-bordered table-striped w-100">
      <thead><tr><th>#</th><th>Placa</th><th>Marca</th><th>Modelo</th><th>Color</th><th>Tipo</th><th>Cliente</th><th>Estado</th><th>Acciones</th></tr></thead>
    </table>
  </div>
</div>

<div class="modal fade" id="modal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <form id="form" class="modal-content" novalidate>
    <div class="modal-header">
      <h5 class="modal-title"></h5>
      <button type="button" class="btn-close" data-bs-dismiss="modal">
        </button>
      </div>
    <div class="modal-body">
      <div class="errores alert alert-danger d-none">
      </div>
      <div class="row g-3">
        <div class="col-md-4">
          <label class="form-label">Placa</label>
          <input name="placa" class="form-control text-uppercase">
        </div>
        <div class="col-md-4">
          <label class="form-label">Marca</label>
          <input name="marca" class="form-control">
        </div>
        <div class="col-md-4">
          <label class="form-label">Modelo</label>
          <input name="modelo" class="form-control">
        </div>
        <div class="col-md-4">
          <label class="form-label">Color</label>
          <input name="color" class="form-control">
        </div>
        <div class="col-md-4">
          <label class="form-label">Tipo</label>
          <select name="tipo" class="form-select">
            <option value="auto">Auto</option>
            <option value="moto">Moto</option>
            <option value="camioneta">Camioneta</option>
          </select>
        </div>
        <div class="col-md-4">
          <label class="form-label">Cliente</label>
          <select name="cliente_id" class="form-select">
            <option value="">-- Sin cliente (visitante) --</option>
            @foreach($clientes as $c)<option value="{{ $c->id }}">{{ $c->nombre }}</option>@endforeach
          </select>
        </div>
      </div>
    </div>
    <div class="modal-footer">
      <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
      <button class="btn btn-primary">Guardar</button>
    </div>
  </form>
</div>
</div>
@endsection

@push('scripts')
<script>
crudModulo({
  base: "{{ route('vehiculos.index') }}", tabla: '#tabla', modal: '#modal', form: '#form', titulo: 'vehículo',
  columnas: [ {data:'id'}, {data:'placa'}, {data:'marca', defaultContent:''}, {data:'modelo', defaultContent:''},
              {data:'color', defaultContent:''}, {data:'tipo'}, {data:'cliente.nombre', defaultContent:''} ],
});
</script>
@endpush
