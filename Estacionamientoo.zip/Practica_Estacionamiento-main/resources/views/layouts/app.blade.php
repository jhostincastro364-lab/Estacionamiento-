<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="csrf-token" content="{{ csrf_token() }}">
  <title>@yield('titulo', 'Estacionamiento') Parking</title>
  <link rel="icon" href="{{ asset('assets/images/favicon.ico') }}">
  <link rel="stylesheet" href="{{ asset('assets/libs/bootstrap/css/bootstrap.min.css') }}">
  <link rel="stylesheet" href="{{ asset('assets/libs/bootstrap-icons/bootstrap-icons.css') }}">
  <link rel="stylesheet" href="{{ asset('assets/css/main.css') }}">
  <link rel="stylesheet" href="https://cdn.datatables.net/1.13.8/css/dataTables.bootstrap5.min.css">
  <style>.modal{z-index:2000}.modal-backdrop{z-index:1990}</style>
</head>
<body>
@php
  $rol = auth()->user()->rol;
  $act = fn (string $patron) => request()->routeIs($patron) ? 'active' : '';
@endphp

<div class="sidebar-wrapper" id="sidebar">
  <a href="{{ route('dashboard') }}" class="sidebar-brand"><i class="bi bi-p-square-fill"></i><span>Parking</span></a>

  <div class="flex-grow-1 overflow-y-auto">
    <div class="sidebar-menu-section">
      <div class="sidebar-menu-title">Menú</div>
      <ul class="sidebar-menu-list">
        <li class="sidebar-menu-item">
          <a href="{{ route('dashboard') }}" class="sidebar-menu-link {{ $act('dashboard') }}">
            <i class="bi bi-grid-fill"></i>
            <span>Inicio</span>
          </a>
        </li>
        <li class="sidebar-menu-item">
          <a href="{{ route('tickets.index') }}" class="sidebar-menu-link {{ $act('tickets.*') }}">
            <i class="bi bi-ticket-perforated"></i>
            <span>Tickets</span>
          </a>
        </li>
      </ul>
    </div>

    @if(in_array($rol, ['administrador','operador']))
    <div class="sidebar-menu-section">
      <div class="sidebar-menu-title">Operaciones</div>
      <ul class="sidebar-menu-list">
        <li class="sidebar-menu-item">
          <a href="{{ route('entrada.create') }}" class="sidebar-menu-link {{ $act('entrada.*') }}">
            <i class="bi bi-box-arrow-in-right"></i>
            <span>Registrar entrada</span>
          </a>
        </li>
        <li class="sidebar-menu-item">
          <a href="{{ route('salida.index') }}" class="sidebar-menu-link {{ $act('salida.*') }}">
            <i class="bi bi-box-arrow-right"></i>
            <span>Salida y cobro</span>
          </a>
        </li>
        <li class="sidebar-menu-item">
          <a href="{{ route('caja.index') }}" class="sidebar-menu-link {{ $act('caja.*') }}">
            <i class="bi bi-cash-coin"></i>
            <span>Caja</span>
          </a>
        </li>
      </ul>
    </div>
    @endif

    <div class="sidebar-menu-section">
      <div class="sidebar-menu-title">Registros</div>
      <ul class="sidebar-menu-list">
        <li class="sidebar-menu-item">
          <a href="{{ route('clientes.index') }}" class="sidebar-menu-link {{ $act('clientes.*') }}">
            <i class="bi bi-people"></i>
            <span>Clientes</span>
          </a>
        </li>
        <li class="sidebar-menu-item">
          <a href="{{ route('vehiculos.index') }}" class="sidebar-menu-link {{ $act('vehiculos.*') }}">
            <i class="bi bi-car-front"></i>
            <span>Vehículos</span>
          </a>
        </li>
        @if($rol === 'administrador')
        <li class="sidebar-menu-item">
          <a href="{{ route('celdas.index') }}" class="sidebar-menu-link {{ $act('celdas.*') }}">
            <i class="bi bi-grid-3x3-gap"></i>
            <span>Celdas</span>
          </a>
        </li>
        <li class="sidebar-menu-item"><a href="{{ route('tarifas.index') }}" class="sidebar-menu-link {{ $act('tarifas.*') }}">
          <i class="bi bi-currency-dollar"></i>
          <span>Tarifas</span>
        </a>
      </li>
        <li class="sidebar-menu-item"><a href="{{ route('usuarios.index') }}" class="sidebar-menu-link {{ $act('usuarios.*') }}">
          <i class="bi bi-shield-lock"></i>
          <span>Roles</span>
        </a>
      </li>
        @endif
      </ul>
    </div>
  </div>

  <div class="sidebar-profile">
    <img src="{{ asset('assets/images/avatar.png') }}" alt="Perfil" class="sidebar-profile-img">
    <div class="sidebar-profile-info">
      <div class="sidebar-profile-name">{{ auth()->user()->name }}</div>
      <div class="sidebar-profile-email">{{ ucfirst($rol) }}</div>
    </div>
  </div>
</div>

<div class="main-wrapper">
  <header class="navbar-custom">
    <div class="navbar-left">
      <button class="btn-desktop-toggle d-none d-xl-flex align-items-center justify-content-center me-3" id="desktop-sidebar-toggle" aria-label="Minimizar menú"><i class="bi bi-chevron-bar-left"></i></button>
      <button class="sidebar-toggle-btn me-2" id="sidebar-toggle" aria-label="Abrir menú"><i class="bi bi-list"></i></button>
    </div>
    <div class="navbar-actions" style="margin-left:auto">
      <button class="navbar-action-btn me-1" aria-label="Pantalla completa" id="btn-fullscreen"><i class="bi bi-arrows-fullscreen"></i></button>
      <div class="dropdown ms-2">
        <button class="navbar-profile-btn dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false" id="profile-dropdown">
          <img src="{{ asset('assets/images/avatar.png') }}" alt="Perfil" class="navbar-profile-img">
          <span class="navbar-profile-name d-none d-md-inline">{{ auth()->user()->name }}</span>
          <i class="bi bi-chevron-down navbar-profile-caret"></i>
        </button>
        <ul class="dropdown-menu dropdown-menu-end dropdown-menu-profile" aria-labelledby="profile-dropdown">
          <li class="dropdown-header">Rol: {{ ucfirst($rol) }}</li>
          <li><hr class="dropdown-divider"></li>

          <li><form method="POST" action="{{ route('logout') }}">
            @csrf
            <button class="dropdown-item text-danger"><i class="bi bi-box-arrow-right"></i> Cerrar sesión</button></form></li>
        </ul>
      </div>
    </div>
  </header>

  <div class="page-header">
    <div><h1 class="page-title">
      @yield('titulo')
    </h1>
  </div>
    <nav aria-label="breadcrumb"><ol class="breadcrumb mb-0">
      <li class="breadcrumb-item"><a href="{{ route('dashboard') }}" class="text-decoration-none text-muted-green">Inicio</a></li>
      <li class="breadcrumb-item active text-main" aria-current="page">
        @yield('titulo')
      </li>
    </ol>
  </nav>
  </div>

  @if(session('ok'))
  <div class="alert alert-success">{{ session('ok') }}</div>
  @endif
  @if($errors->any())
  <div class="alert alert-danger">
    <ul class="mb-0">
    @foreach($errors->all() as $e)
    <li>{{ $e }}</li>
    @endforeach
  </ul>
  </div>
  @endif

  @yield('contenido')

  <footer class="footer-custom">
    <div class="footer-left">
      <span class="footer-logo"><i class="bi bi-p-square-fill"></i> Parking</span>
    </div>
  </footer>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="{{ asset('assets/libs/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
<script src="https://cdn.datatables.net/1.13.8/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.8/js/dataTables.bootstrap5.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="{{ asset('assets/js/dashboard.js') }}"></script>
<script src="{{ asset('assets/js/crud.js') }}"></script>
<script>

  $.ajaxPrefilter(function (opciones, original, xhr) {
    if (!opciones.crossDomain) {
      xhr.setRequestHeader('X-CSRF-TOKEN', $('meta[name="csrf-token"]').attr('content'));
      xhr.setRequestHeader('Accept', 'application/json');
    }
  });

  $('.datatable').DataTable({ language: { url: 'https://cdn.datatables.net/plug-ins/1.13.8/i18n/es-ES.json' }, order: [[0, 'desc']] });

</script>
@stack('scripts')
</body>
</html>
