
<div class="card p-3 h-100">
  <div class="d-flex justify-content-between align-items-center">
    <div><div class="text-muted-green small">{{ $t }}</div>
    <div class="h3 mb-0" @isset($id) id="{{ $id }}" @endisset>{{ $v ?? 0 }}</div>
  </div>
    <i class="bi {{ $i }} fs-1 text-{{ $c ?? 'secondary' }}"></i>
  </div>
</div>
