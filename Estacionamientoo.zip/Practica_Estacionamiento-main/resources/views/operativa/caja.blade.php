@extends('layouts.app')
@section('titulo', 'Caja')
@section('contenido')
<div class="card">
  <div class="card-body">
  <table class="table table-bordered table-striped w-100">
    <thead>
      <tr>
        <th>N°</th>
        <th>Hora</th>
        <th>Ticket</th>
        <th>Placa</th>
        <th>Método</th>
        <th>Referencia</th>
        <th>Cajero</th>
        <th>Monto</th>
      </tr>
    </thead>
    <tbody>@foreach($pagos as $p)
      <tr>
        <td>{{ $p->id }}</td>
        <td>{{ $p->created_at->format('H:i') }}</td>
        <td>{{ $p->ticket->codigo }}</td>
        <td>{{ $p->ticket->vehiculo->placa }}</td>
        <td>{{ strtoupper($p->metodo) }}</td>
        <td>{{ $p->referencia }}</td>
        <td>{{ $p->cajero->name }}</td>
        <td>{{ number_format($p->monto,2) }}</td>
      </tr>
    @endforeach</tbody>
  </table>
</div>
</div>
@endsection
