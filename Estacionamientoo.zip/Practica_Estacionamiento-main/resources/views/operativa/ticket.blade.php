@extends('layouts.app')
@section('titulo', 'Ticket '.$ticket->codigo)
@section('contenido')
<div class="card col-md-5" id="ticket">
  <div class="card-body">
  <h4 class="text-center">TICKET DE ESTACIONAMIENTO</h4>
  <hr>
  <p><b>Código:</b> {{ $ticket->codigo }}</p>
  <p><b>Placa:</b> {{ $ticket->vehiculo->placa }} ({{ $ticket->vehiculo->tipo }})</p>
  <p><b>Celda:</b> {{ $ticket->celda->codigo }} - {{ $ticket->celda->piso }}</p>
  <p><b>Entrada:</b> {{ $ticket->entrada->format('d/m/Y H:i:s') }}</p>
  @if($ticket->estado === 'cobrado')
    <p><b>Salida:</b> {{ $ticket->salida->format('d/m/Y H:i:s') }}</p>
    <p><b>Tiempo:</b> {{ $ticket->minutos }} min</p>
    <p><b>Total:</b> Bs {{ number_format($ticket->monto, 2) }} ({{ strtoupper($ticket->pago->metodo) }})</p>
  @else
    <p class="text-success">
      <b>Vehículo en el estacionamiento</b>
    </p>
  @endif
  <button class="btn btn-secondary btn-block d-print-none" onclick="window.print()">
    <i class="bi bi-printer"></i>
     Imprimir
  </button>
</div>
</div>
@endsection
