@extends('layouts.app')
@section('titulo', 'Tickets')
@section('contenido')
<div class="card">
  <div class="card-body">
<table class="table table-bordered table-striped w-100">
  <thead>
    <tr>
      <th>N°</th>
      <th>Código</th>
      <th>Placa</th>
      <th>Celda</th>
      <th>Entrada</th>
      <th>Salida</th>
      <th>Monto</th>
      <th>Estado</th>
      <th>
        </th>
      </tr>
    </thead>
  <tbody>
    @foreach($tickets as $t)
    <tr>
      <td>{{ $t->id }}</td>
      <td>{{ $t->codigo }}</td>
      <td>{{ $t->vehiculo->placa }}</td>
      <td>{{ $t->celda->codigo }}</td>
      <td>{{ $t->entrada->format('d/m/Y H:i') }}</td>
      <td>{{ $t->salida?->format('d/m/Y H:i') }}</td>
      <td>{{ $t->monto }}</td>
      <td>
        <span class="badge text-bg-{{ $t->estado=='cobrado' ? 'success' : 'warning' }}">{{ $t->estado }}</span>
      </td>
      <td>
        <a href="{{ route('tickets.show', $t->id) }}" class="btn btn-sm btn-info">
          <i class="bi bi-eye"></i>
        </a>
      </td>
      </tr>
  @endforeach
</tbody>
</table>
</div>
</div>
@endsection
