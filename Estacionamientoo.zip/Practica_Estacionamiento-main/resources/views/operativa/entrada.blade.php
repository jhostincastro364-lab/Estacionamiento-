@extends('layouts.app')
@section('titulo', 'Registrar entrada')
@section('contenido')
<div class="card">
  <div class="card-body">
  <form method="POST" action="{{ route('entrada.store') }}">
    @csrf
    <div class="row">
      <div class="mb-3 col-md-4">
        <label>Placa</label>
        <input name="placa" class="form-control text-uppercase" value="{{ old('placa') }}" required>
      </div>
      <div class="mb-3 col-md-4">
        <label>Tipo</label>
        <select name="tipo" class="form-select">
          @foreach(['auto'=>'Auto','moto'=>'Moto','camioneta'=>'Camioneta'] as $k=>$v)
          <option value="{{ $k }}">{{ $v }}</option>
          @endforeach
        </select>
        </div>
      <div class="mb-3 col-md-4">
        <label>Celda libre</label>
        <select name="celda_id" class="form-select" required>
          <option value="">-- Seleccione --</option>
          @foreach($celdas as $c)
          <option value="{{ $c->id }}">{{ $c->codigo }} ({{ $c->piso }} - Sector {{ $c->sector }})
            </option>
            @endforeach
        </select>
      </div>
      <div class="mb-3 col-md-4">
        <label>Marca</label>
        <input name="marca" class="form-control" value="{{ old('marca') }}">
      </div>
      <div class="mb-3 col-md-4">
        <label>Modelo</label>
        <input name="modelo" class="form-control" value="{{ old('modelo') }}">
      </div>
      <div class="mb-3 col-md-4">
        <label>Color</label>
        <input name="color" class="form-control" value="{{ old('color') }}">
      </div>
    </div>
    <p class="text-muted-green">Si la placa no existe, el vehículo se registra automáticamente. Se genera un ticket con la hora de entrada.</p>
    <button class="btn btn-success"><i class="bi bi-ticket-perforated"></i> Generar ticket</button>
  </form>
</div>
</div>
@endsection
