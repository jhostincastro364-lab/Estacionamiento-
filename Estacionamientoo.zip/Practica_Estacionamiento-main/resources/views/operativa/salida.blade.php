@extends('layouts.app')
@section('titulo', 'Salida y cobro')
@section('contenido')
<div class="card">
  <div class="card-body">
  <div class="input-group mb-3 col-md-6 p-0">
    <input id="q" class="form-control text-uppercase" placeholder="Placa o código de ticket">
    <button id="btn-buscar" class="btn btn-primary"><i class="bi bi-search"></i> Buscar</button>
  </div>

  <div id="resumen" class="d-none">
    <table class="table table-sm w-50">
      <tr>
        <th>Ticket</th>
        <td id="r-codigo"></td>
      </tr>
      <tr>
        <th>Placa / Tipo</th>
        <td id="r-placa"></td>
      </tr>
      <tr>
        <th>Celda</th>
        <td id="r-celda"></td>
      </tr>
      <tr>
        <th>Entrada</th>
        <td id="r-entrada"></td>
      </tr>
      <tr>
        <th>Salida</th>
        <td id="r-salida"></td>
      </tr>
      <tr>
        <th>Tiempo (min)</th>
        <td id="r-minutos"></td>
      </tr>
      <tr class="table-success">
        <th>TOTAL A PAGAR (Bs)</th>
        <th id="r-monto" class="h4">
          </th>
        </tr>
    </table>
    <div class="row g-2 col-md-8">
      <div class="col-md-4">
        <select id="metodo" class="form-select">
          <option value="efectivo">Efectivo</option>
          <option value="qr">QR</option>
        </select>
        </div>
      <div class="col-md-5">
        <input id="referencia" class="form-control d-none" placeholder="Nro. de transacción QR">
      </div>
      <div class="col-md-3">
        <button id="btn-cobrar" class="btn btn-success btn-block">
          <i class="bi bi-check-lg"></i> 
          Cobrar
        </button>
      </div>
    </div>
  </div>
</div></div>
@endsection

@push('scripts')
<script>
let ticketId = null;

// 1) Buscar ticket y calcular tiempo/tarifa por AJAX
function buscar() {
  $.post("{{ route('salida.calcular') }}", { q: $('#q').val() })
    .done(r => {
      ticketId = r.ticket_id;
      $('#r-codigo').text(r.codigo); $('#r-placa').text(r.placa + ' / ' + r.tipo); $('#r-celda').text(r.celda);
      $('#r-entrada').text(r.entrada); $('#r-salida').text(r.salida); $('#r-minutos').text(r.minutos); $('#r-monto').text(r.monto);
      $('#resumen').removeClass('d-none');
    })
    .fail(x => { $('#resumen').addClass('d-none'); Swal.fire('Atención', x.responseJSON?.mensaje ?? 'Error al buscar', 'warning'); });
}
$('#btn-buscar').on('click', buscar);
$('#q').on('keypress', e => { if (e.which === 13) buscar(); });

// 2) Si el método es QR se pide la referencia
$('#metodo').on('change', function () { $('#referencia').toggleClass('d-none', this.value !== 'qr'); });

// 3) Confirmar cobro: cierra el ticket, libera la celda y redirige al ticket digital
$('#btn-cobrar').on('click', function () {
  $.post("{{ route('salida.cobrar') }}", { ticket_id: ticketId, metodo: $('#metodo').val(), referencia: $('#referencia').val() })
    .done(r => window.location = r.url)
    .fail(x => Swal.fire('Error', x.responseJSON?.message ?? 'No se pudo cobrar', 'error'));
});
</script>
@endpush
