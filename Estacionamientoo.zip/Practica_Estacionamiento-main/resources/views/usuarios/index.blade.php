@extends('layouts.app')
@section('titulo', 'Usuarios y roles')
@section('contenido')
<div class="card">
  <div class="card-header">
    <button id="btn-nuevo" class="btn btn-primary">
      <i class="bi bi-plus-lg"></i> 
      Nuevo usuario
    </button>
    </div>
  <div class="card-body">
    <table id="tabla" class="table table-bordered table-striped w-100">
      <thead>
        <tr>
          <th>N°</th>
          <th>Nombre</th>
          <th>Correo</th>
          <th>Rol</th>
          <th>Estado</th>
          <th>Acciones</th>
        </tr>
      </thead>
    </table>
  </div>
</div>

<div class="modal fade" id="modal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog">
    <form id="form" class="modal-content" novalidate autocomplete="off">
    <div class="modal-header">
      <h5 class="modal-title"></h5>
      <button type="button" class="btn-close" data-bs-dismiss="modal">
        </button>
      </div>
    <div class="modal-body">
      <div class="errores alert alert-danger d-none">
      </div>
      <div class="row g-3">
        <div class="col-12">
          <label class="form-label">Nombre</label>
          <input name="name" class="form-control"></div>
        <div class="col-12">
          <label class="form-label">Correo</label>
          <input type="email" name="email" class="form-control">
        </div>
        <div class="col-md-6">
          <label class="form-label">Rol</label>
          <select name="rol" class="form-select">
            <option value="administrador">Administrador</option>
            <option value="operador">Operador / Cajero</option>
            <option value="supervisor">Supervisor</option>
          </select>
        </div>
        <div class="col-md-6">
          <label class="form-label">Contraseña</label>
          <input type="password" name="password" class="form-control" autocomplete="new-password">
          <div class="form-text">Al editar, déjala vacía para no cambiarla.</div>
        </div>
      </div>
    </div>
    <div class="modal-footer">
      <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
      <button class="btn btn-primary">
        Guardar
      </button>
      </div>
  </form>
</div>
</div>
@endsection

@push('scripts')
<script>
crudModulo({
  base: "{{ route('usuarios.index') }}", tabla: '#tabla', modal: '#modal', form: '#form', titulo: 'usuario',
  columnas: [ {data:'id'}, {data:'name'}, {data:'email'}, {data:'rol'} ],
});
</script>
@endpush
