<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Ingresar</title>
  <link rel="icon" href="{{ asset('assets/images/favicon.ico') }}">
  <link rel="stylesheet" href="{{ asset('assets/libs/bootstrap/css/bootstrap.min.css') }}">
  <link rel="stylesheet" href="{{ asset('assets/libs/bootstrap-icons/bootstrap-icons.css') }}">
  <link rel="stylesheet" href="{{ asset('assets/css/main.css') }}">
</head>
<body>
<div class="login-wrapper">
  <div class="login-bg-shape login-bg-shape-1"></div>
  <div class="login-bg-shape login-bg-shape-2"></div>
  <div class="login-card">
    <a href="{{ route('login') }}" class="login-brand text-decoration-none"><i class="bi bi-p-square-fill"></i><span>Parking</span></a>
    <p class="login-subtitle">Inicia sesión para acceder al sistema</p>

    @if($errors->any())
    <div class="alert alert-danger py-2">{{ $errors->first() }}</div>
    @endif

    <form action="{{ route('login') }}" method="POST" id="loginForm" novalidate>
      @csrf
      <div class="login-form-group">
        <label for="email" class="login-form-label">Correo</label>
        <div class="login-input-group"><i class="bi bi-envelope input-icon"></i>
          <input type="email" id="email" name="email" value="{{ old('email') }}" class="login-input" placeholder="correo@ejemplo.com" required autofocus></div>
      </div>
      <div class="login-form-group">
        <label for="password" class="login-form-label">Contraseña</label>
        <div class="login-input-group">
          <i class="bi bi-shield-lock input-icon"></i>
          <input type="password" id="password" name="password" class="login-input login-input-password" placeholder="••••••••" required>
          <button type="button" class="password-toggle-btn" id="toggle-password" aria-label="Mostrar contraseña">
            <i class="bi bi-eye"></i>
          </button>
        </div>
      </div>
      <div class="login-options">
        <label class="custom-control-label">
          <input type="checkbox" class="custom-checkbox-input" name="recordar">
          <span>Recordarme</span>
        </label>
      </div>
      <button type="submit" class="btn-login">
        <span>Ingresar</span>
        <i class="bi bi-arrow-right"></i>
      </button>
    </form>
  </div>
</div>
<script src="{{ asset('assets/libs/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
<script src="{{ asset('assets/js/auth.js') }}"></script>
</body>
</html>
