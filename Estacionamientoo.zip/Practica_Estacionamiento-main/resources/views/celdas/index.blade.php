@extends('layouts.app')
@section('titulo', 'Celdas de estacionamiento')
@section('contenido')
<div class="card">
  <div class="card-header">
    <button id="btn-nuevo" class="btn btn-primary">
      <i class="bi bi-plus-lg"></i> Nueva celda</button>
    </div>
  <div class="card-body">
    <table id="tabla" class="table table-bordered table-striped w-100">
      <thead>
        <tr>
          <th>N°</th>
          <th>Piso</th>
          <th>Sector</th>
          <th>Código</th>
          <th>Ocupación</th>
          <th>Estado</th>
          <th>Acciones</th>
        </tr>
      </thead>
    </table>
  </div>
</div>

<div class="modal fade" id="modal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog">
    <form id="form" class="modal-content" novalidate>
    <div class="modal-header">
      <h5 class="modal-title"></h5>
      <button type="button" class="btn-close" data-bs-dismiss="modal">
        </button>
      </div>
    <div class="modal-body">
      <div class="errores alert alert-danger d-none"></div>
      <div class="row g-3">
        <div class="col-md-6">
          <label class="form-label">Piso</label>
          <input name="piso" class="form-control" placeholder="Piso 1">
        </div>
        <div class="col-md-6">
          <label class="form-label">Sector </label>
          <input name="sector" class="form-control" placeholder="A">
        </div>
        <div class="col-12">
          <label class="form-label">Código de celda</label>
          <input name="codigo" class="form-control" placeholder="P1-A1">
        </div>
      </div>
    </div>
    <div class="modal-footer"><button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button><button class="btn btn-primary">Guardar</button></div>
  </form>
</div>
</div>
@endsection

@push('scripts')
<script>
crudModulo({
  base: "{{ route('celdas.index') }}", tabla: '#tabla', modal: '#modal', form: '#form', titulo: 'celda',
  columnas: [ {data:'id'}, {data:'piso'}, {data:'sector'}, {data:'codigo'},
              {data:'ocupacion', render: v => v === 'Ocupada' ? '<span class="badge text-bg-danger">Ocupada</span>' : '<span class="badge text-bg-success">Libre</span>'} ],
});
</script>
@endpush
