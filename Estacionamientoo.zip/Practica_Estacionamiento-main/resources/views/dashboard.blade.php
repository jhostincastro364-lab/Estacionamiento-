@extends('layouts.app')
@section('titulo', 'Panel principal')
@section('contenido')
<div class="row g-3">
  @foreach([['Celdas libres',$celdasLibres,'bi-check-circle','success'],['Celdas ocupadas',$celdasOcupadas,'bi-car-front','danger'],['Vehículos en curso',$enCurso,'bi-clock-history','warning'],['Ingresos de hoy (Bs)',number_format($ingresosHoy,2),'bi-cash-coin','info'],['Clientes activos',$clientes,'bi-people','primary'],['Vehículos activos',$vehiculos,'bi-card-text','secondary']] as [$t,$v,$i,$c])
  <div class="col-md-4 col-sm-6">
    @include('layouts.stat', ['t'=>$t,'v'=>$v,'i'=>$i,'c'=>$c])
  </div>
  @endforeach
</div>
@endsection
