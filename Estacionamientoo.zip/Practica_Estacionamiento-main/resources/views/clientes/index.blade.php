@extends('layouts.app')
@section('titulo', 'Clientes / Abonados')
@section('contenido')
<div class="card">
  <div class="card-header">
    <button id="btn-nuevo" class="btn btn-primary">
      <i class="bi bi-plus-lg"></i> Nuevo cliente</button>
    </div>
  <div class="card-body">
    <table id="tabla" class="table table-bordered table-striped w-100">
      <thead>
        <tr>
          <th>N°</th>
          <th>Nombre</th>
          <th>CI</th>
          <th>Teléfono</th>
          <th>Tipo</th>
          <th>Convenio</th>
          <th>Fin abono</th>
          <th>Estado</th>
          <th>Acciones</th>
        </tr>
      </thead>
    </table>
  </div>
</div>

<div class="modal fade" id="modal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <form id="form" class="modal-content" novalidate>
    <div class="modal-header">
      <h5 class="modal-title"></h5>
      <button type="button" class="btn-close" data-bs-dismiss="modal">
        </button>
      </div>
    <div class="modal-body">
      <div class="errores alert alert-danger d-none"></div>
      <div class="row g-3">
        <div class="col-md-6">
          <label class="form-label">Nombre completo</label>
          <input name="nombre" class="form-control">
        </div>
        <div class="col-md-6">
          <label class="form-label">CI / NIT</label>
          <input name="ci" class="form-control">
        </div>
        <div class="col-md-6">
          <label class="form-label">Teléfono</label>
          <input name="telefono" class="form-control">
        </div>
        <div class="col-md-6">
          <label class="form-label">Correo</label>
          <input type="email" name="email" class="form-control">
        </div>
        <div class="col-md-6">
          <label class="form-label">Tipo de cliente</label>
          <select name="tipo" class="form-select">
            <option value="habitual">Habitual</option>
            <option value="abonado">Abonado (mensualidad)</option>
          </select>
        </div>
        <div class="col-md-6">
          <label class="form-label">Vigencia del abono</label>
          <input type="date" name="fecha_fin_abono" class="form-control">
        </div>
        <div class="col-12">
          <label class="form-label">Convenio</label>
          <input name="convenio" class="form-control">
        </div>
      </div>
    </div>
    <div class="modal-footer">
      <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
      <button class="btn btn-primary">Guardar</button>
    </div>
  </form>
</div>
</div>
@endsection

@push('scripts')
<script>
crudModulo({
  base: "{{ route('clientes.index') }}", tabla: '#tabla', modal: '#modal', form: '#form', titulo: 'cliente',
  columnas: [ {data:'id'}, {data:'nombre'}, {data:'ci', defaultContent:''}, {data:'telefono', defaultContent:''}, {data:'tipo'},
              {data:'convenio', defaultContent:''}, {data:'fecha_fin_abono', defaultContent:''} ],
});
</script>
@endpush
