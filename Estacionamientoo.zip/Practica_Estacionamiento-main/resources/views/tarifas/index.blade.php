@extends('layouts.app')
@section('titulo', 'Tarifas')
@section('contenido')
<div class="card">
  <div class="card-header">
    <button id="btn-nuevo" class="btn btn-primary">
      <i class="bi bi-plus-lg"></i>
       Nueva tarifa
    </button>
    </div>
  <div class="card-body">
    <table id="tabla" class="table table-bordered table-striped w-100">
      <thead>
        <tr>
        <th>N°</th>
        <th>Tipo de vehículo</th>
        <th>Precio por hora (Bs)</th>
        <th>Fracción (min)</th>
        <th>Estado</th>
        <th>Acciones</th>
      </tr>
      </thead>
    </table>
  </div>
</div>

<div class="modal fade" id="modal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog">
    <form id="form" class="modal-content" novalidate>
    <div class="modal-header">
      <h5 class="modal-title"></h5>
      <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
    </div>
    <div class="modal-body">
      <div class="errores alert alert-danger d-none">
      </div>
      <div class="row g-3">
        <div class="col-12">
          <label class="form-label">Tipo de vehículo *</label>
          <select name="tipo_vehiculo" class="form-select">
            <option value="auto">Auto</option>
            <option value="moto">Moto</option>
            <option value="camioneta">Camioneta</option>
          </select>
        </div>
        <div class="col-md-6">
          <label class="form-label">Precio por hora (Bs) </label>
          <input type="number" step="any" name="precio_hora" class="form-control">
        </div>
        <div class="col-md-6">
          <label class="form-label">Fracción de cobro (minutos) </label>
          <input type="number" name="fraccion_minutos" class="form-control" value="15">
        </div>
      </div>
    </div>
    <div class="modal-footer">
      <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
        Cancelar
      </button>
      <button class="btn btn-primary">Guardar
      </button>
    </div>
  </form>
</div>
</div>
@endsection

@push('scripts')
<script>
crudModulo({
  base: "{{ route('tarifas.index') }}", tabla: '#tabla', modal: '#modal', form: '#form', titulo: 'tarifa',
  columnas: [ {data:'id'}, {data:'tipo_vehiculo'}, {data:'precio_hora'}, {data:'fraccion_minutos'} ],
});
</script>
@endpush
