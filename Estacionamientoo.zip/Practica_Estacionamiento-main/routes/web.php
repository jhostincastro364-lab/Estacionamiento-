<?php
use App\Http\Controllers\{AuthController, CeldaController, ClienteController, ReporteController, TarifaController, TicketController, UsuarioController, VehiculoController};
use App\Models\{Celda, Cliente, Pago, Ticket, Vehiculo};
use Illuminate\Support\Facades\Route;
Route::get('/', fn () => redirect()->route('dashboard'));
Route::get('login', [AuthController::class, 'formulario'])->name('login')->middleware('guest');
Route::post('login', [AuthController::class, 'login'])->middleware('guest');
Route::post('logout', [AuthController::class, 'logout'])->name('logout');

$crud = function (string $ruta, string $controlador) {
    Route::get("$ruta/datos", [$controlador, 'datos'])->name("$ruta.datos");
    Route::resource($ruta, $controlador)->only(['index', 'store', 'update']);
    Route::patch("$ruta/{id}/estado", [$controlador, 'estado'])->name("$ruta.estado");
};

Route::middleware('auth')->group(function () use ($crud) {

    Route::get('dashboard', fn () => view('dashboard', [
        'celdasLibres' => Celda::where('estado', 1)->where('ocupada', 0)->count(),
        'celdasOcupadas' => Celda::where('estado', 1)->where('ocupada', 1)->count(),
        'clientes' => Cliente::where('estado', 1)->count(),
        'vehiculos' => Vehiculo::where('estado', 1)->count(),
        'ingresosHoy' => Pago::whereDate('created_at', today())->sum('monto'),
        'enCurso' => Ticket::where('estado', 'en_curso')->count(),
    ]))->name('dashboard');

    Route::middleware('rol:administrador')->group(function () use ($crud) {
        $crud('usuarios', UsuarioController::class);
        $crud('tarifas', TarifaController::class);
        $crud('celdas', CeldaController::class);
    });

    Route::middleware('rol:administrador,operador,supervisor')->group(function () use ($crud) {
        $crud('clientes', ClienteController::class);
        $crud('vehiculos', VehiculoController::class);
    });

    Route::middleware('rol:administrador,operador')->group(function () {
        Route::get('entrada', [TicketController::class, 'entrada'])->name('entrada.create');
        Route::post('entrada', [TicketController::class, 'guardarEntrada'])->name('entrada.store');
        Route::get('salida', [TicketController::class, 'salida'])->name('salida.index');
        Route::post('salida/calcular', [TicketController::class, 'calcular'])->name('salida.calcular');
        Route::post('salida/cobrar', [TicketController::class, 'cobrar'])->name('salida.cobrar');
        Route::get('caja', [TicketController::class, 'caja'])->name('caja.index');
    });

    Route::get('tickets', [TicketController::class, 'index'])->name('tickets.index');
    Route::get('tickets/{id}', [TicketController::class, 'show'])->name('tickets.show');

    Route::middleware('rol:administrador,supervisor')->prefix('reportes')->name('reportes.')->group(function () {
        Route::get('/', [ReporteController::class, 'index'])->name('index');
        Route::get('datos', [ReporteController::class, 'datos'])->name('datos');   // AJAX
        Route::get('pdf', [ReporteController::class, 'pdf'])->name('pdf');
        Route::get('excel', [ReporteController::class, 'excel'])->name('excel');
    });
});
