<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Cliente extends Model
{
    protected $fillable = ['nombre', 'ci', 'telefono', 'email', 'tipo', 'convenio', 'fecha_fin_abono', 'estado'];
    protected $casts = ['estado' => 'boolean', 'fecha_fin_abono' => 'date:Y-m-d'];

    public function vehiculos() { 
        return $this->hasMany(Vehiculo::class); 
        }

    public function abonoVigente(): bool
    {
        return $this->tipo === 'abonado' && $this->fecha_fin_abono && $this->fecha_fin_abono->endOfDay()->isFuture();
    }
}
