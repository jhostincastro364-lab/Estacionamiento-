<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Pago extends Model
{
    protected $fillable = ['ticket_id', 'user_id', 'monto', 'metodo', 'referencia'];
    public function ticket() { return $this->belongsTo(Ticket::class); }
    public function cajero()  { return $this->belongsTo(User::class, 'user_id'); }
}
