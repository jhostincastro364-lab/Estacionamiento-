<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Celda extends Model
{
    protected $fillable = ['piso', 'sector', 'codigo', 'ocupada', 'estado'];
    protected $casts = ['ocupada' => 'boolean', 'estado' => 'boolean'];
    protected $appends = ['ocupacion']; // se incluye en el JSON del DataTable
    
    public function getOcupacionAttribute(): string { return $this->ocupada ? 'Ocupada' : 'Libre'; }
}
