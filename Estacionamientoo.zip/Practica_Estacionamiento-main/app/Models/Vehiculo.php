<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Vehiculo extends Model
{
    protected $fillable = ['cliente_id', 'placa', 'marca', 'modelo', 'color', 'tipo', 'estado'];
    protected $casts = ['estado' => 'boolean'];
    public function cliente() { return $this->belongsTo(Cliente::class); }
    public function tickets() { return $this->hasMany(Ticket::class); }
}
