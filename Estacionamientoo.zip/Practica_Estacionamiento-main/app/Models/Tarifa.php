<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Tarifa extends Model
{
    protected $fillable = ['tipo_vehiculo', 'precio_hora', 'fraccion_minutos', 'estado'];
    protected $casts = ['estado' => 'boolean'];
}
