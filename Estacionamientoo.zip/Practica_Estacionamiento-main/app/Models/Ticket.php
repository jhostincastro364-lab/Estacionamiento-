<?php
namespace App\Models;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

class Ticket extends Model
{
    protected $fillable = ['codigo', 'vehiculo_id', 'celda_id', 'user_id', 'entrada', 'salida', 'minutos', 'monto', 'estado'];
    protected $casts = ['entrada' => 'datetime', 'salida' => 'datetime'];

    public function vehiculo() { return $this->belongsTo(Vehiculo::class); }
    public function celda()    { return $this->belongsTo(Celda::class); }
    public function operador() { return $this->belongsTo(User::class, 'user_id'); }
    public function pago()     { return $this->hasOne(Pago::class); }

    /**Calcula minutos y monto*/
    public function calcular(?Carbon $salida = null): array
    {
        $salida = $salida ?? now();
        $minutos = max(1, (int) ceil(abs($this->entrada->diffInMinutes($salida))));

        $tarifa = Tarifa::where('tipo_vehiculo', $this->vehiculo->tipo)->first();
        $fraccion = $tarifa->fraccion_minutos ?? 15;
        $fracciones = (int) ceil($minutos / $fraccion);
        $monto = round($fracciones * ($tarifa->precio_hora ?? 0) * $fraccion / 60, 2);

        if ($this->vehiculo->cliente?->abonoVigente()) {
            $monto = 0; // convenio / mensualidad vigente
        }
        return ['minutos' => $minutos, 'monto' => $monto, 'salida' => $salida];
    }
}
