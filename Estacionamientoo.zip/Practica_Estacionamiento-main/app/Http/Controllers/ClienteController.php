<?php
namespace App\Http\Controllers;
use App\Models\Cliente;


class ClienteController extends CrudController
{
    protected string $modelo = Cliente::class;
    protected string $vista = 'clientes.index';
    protected function reglas(?int $id = null): array
    {
        return [
            'nombre' => 'required|string|max:255', 'ci' => 'nullable|max:20', 'telefono' => 'nullable|max:20',
            'email' => 'nullable|email', 'tipo' => 'required|in:habitual,abonado',
            'convenio' => 'nullable|max:255', 'fecha_fin_abono' => 'nullable|date',
        ];
    }
}
