<?php
namespace App\Http\Controllers;
use App\Models\Celda;

class CeldaController extends CrudController
{
    protected string $modelo = Celda::class;
    protected string $vista = 'celdas.index';
    protected function reglas(?int $id = null): array
    {
        return ['piso' => 'required|max:30', 'sector' => 'required|max:30', 'codigo' => 'required|max:20|unique:celdas,codigo,'.$id];
    }
}
