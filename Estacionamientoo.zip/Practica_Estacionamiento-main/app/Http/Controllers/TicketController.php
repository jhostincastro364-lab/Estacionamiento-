<?php
namespace App\Http\Controllers;
use App\Models\{Celda, Pago, Ticket, Vehiculo};
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class TicketController extends Controller
{
    public function index()
    {
        $tickets = Ticket::with(['vehiculo', 'celda'])->orderByDesc('id')->get();
        return view('operativa.tickets', compact('tickets'));
    }
    public function entrada()
    {
        $celdas = Celda::where('estado', 1)->where('ocupada', 0)->orderBy('codigo')->get();
        return view('operativa.entrada', compact('celdas'));
    }

    public function guardarEntrada(Request $request)
    {
        $d = $request->validate([
            'placa' => 'required|max:15', 'tipo' => 'required|in:auto,moto,camioneta',
            'marca' => 'nullable|max:255', 'modelo' => 'nullable|max:255', 'color' => 'nullable|max:30',
            'celda_id' => 'required|exists:celdas,id',
        ]);

        $ticket = DB::transaction(function () use ($d) {
            $celda = Celda::lockForUpdate()->findOrFail($d['celda_id']);
            abort_if($celda->ocupada || !$celda->estado, 422, 'La celda ya no está disponible.');

            $vehiculo = Vehiculo::firstOrCreate(
                ['placa' => strtoupper(trim($d['placa']))],
                ['tipo' => $d['tipo'], 'marca' => $d['marca'] ?? null, 'modelo' => $d['modelo'] ?? null, 'color' => $d['color'] ?? null]
            );
            abort_if(!$vehiculo->estado, 422, 'El vehículo está inactivo.');
            abort_if(Ticket::where('vehiculo_id', $vehiculo->id)->where('estado', 'en_curso')->exists(), 422, 'El vehículo ya tiene una entrada activa.');

            $celda->update(['ocupada' => true]);
            return Ticket::create([
                'codigo' => 'T'.now()->format('ymdHis').rand(10, 99),
                'vehiculo_id' => $vehiculo->id, 'celda_id' => $celda->id,
                'user_id' => auth()->id(), 'entrada' => now(),
            ]);
        });

        return redirect()->route('tickets.show', $ticket->id)->with('ok', 'Entrada registrada.');
    }

    public function show($id)
    {
        $ticket = Ticket::with(['vehiculo', 'celda', 'pago'])->findOrFail($id);
        return view('operativa.ticket', compact('ticket'));
    }

    public function salida() { return view('operativa.salida'); }

    public function calcular(Request $request)
    {
        $q = strtoupper(trim($request->validate(['q' => 'required'])['q']));
        $ticket = Ticket::with(['vehiculo.cliente', 'celda'])->where('estado', 'en_curso')
            ->where(fn ($w) => $w->where('codigo', $q)->orWhereHas('vehiculo', fn ($v) => $v->where('placa', $q)))
            ->first();

        if (!$ticket) return response()->json(['ok' => false, 'mensaje' => 'No hay un ticket en curso para ese dato.'], 404);

        $c = $ticket->calcular();
        return response()->json([
            'ok' => true, 'ticket_id' => $ticket->id, 'codigo' => $ticket->codigo,
            'placa' => $ticket->vehiculo->placa, 'tipo' => $ticket->vehiculo->tipo, 'celda' => $ticket->celda->codigo,
            'entrada' => $ticket->entrada->format('d/m/Y H:i'), 'salida' => $c['salida']->format('d/m/Y H:i'),
            'minutos' => $c['minutos'], 'monto' => number_format($c['monto'], 2, '.', ''),
        ]);
    }

    public function cobrar(Request $request)
    {
        $d = $request->validate(['ticket_id' => 'required|exists:tickets,id', 'metodo' => 'required|in:efectivo,qr', 'referencia' => 'nullable|max:100']);

        $ticket = DB::transaction(function () use ($d) {
            $ticket = Ticket::with('vehiculo.cliente')->lockForUpdate()->findOrFail($d['ticket_id']);
            abort_if($ticket->estado !== 'en_curso', 422, 'El ticket ya fue cobrado.');

            $c = $ticket->calcular(); // el monto se recalcula en el servidor (nunca se confía en el navegador)
            $ticket->update(['salida' => $c['salida'], 'minutos' => $c['minutos'], 'monto' => $c['monto'], 'estado' => 'cobrado']);
            $ticket->celda->update(['ocupada' => false]);

            Pago::create(['ticket_id' => $ticket->id, 'user_id' => auth()->id(), 'monto' => $c['monto'], 'metodo' => $d['metodo'], 'referencia' => $d['referencia'] ?? null]);
            return $ticket;
        });

        return response()->json(['ok' => true, 'url' => route('tickets.show', $ticket->id)]);
    }

    public function caja(Request $request)
    {
        $fecha = $request->get('fecha', now()->toDateString());
        $pagos = Pago::with(['ticket.vehiculo', 'cajero'])->whereDate('created_at', $fecha)->orderByDesc('id')->get();
        return view('operativa.caja', compact('pagos', 'fecha'));
    }
}
