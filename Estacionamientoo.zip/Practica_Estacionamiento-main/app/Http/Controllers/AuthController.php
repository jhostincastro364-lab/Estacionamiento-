<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    public function formulario() { 
        return view('auth.login'); 
        }

    public function login(Request $request)
    {
        $datos = $request->validate(['email' => 'required|email', 'password' => 'required']);

        if (Auth::attempt($datos + ['estado' => 1], $request->boolean('recordar'))) {
            $request->session()->regenerate();       // evita fijación de sesión
            return redirect()->intended(route('dashboard'));
        }
        return back()->withErrors(['email' => 'Credenciales incorrectas o usuario inactivo.'])->onlyInput('email');
    }

    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        return redirect()->route('login');
    }
}
