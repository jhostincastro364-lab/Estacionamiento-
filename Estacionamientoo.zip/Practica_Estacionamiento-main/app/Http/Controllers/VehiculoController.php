<?php
namespace App\Http\Controllers;
use App\Models\{Cliente, Vehiculo};

class VehiculoController extends CrudController
{
    protected string $modelo = Vehiculo::class;
    protected string $vista = 'vehiculos.index';
    protected function consulta() { return Vehiculo::with('cliente:id,nombre'); }
    protected function datosVista(): array
    {
        return ['clientes' => Cliente::where('estado', 1)->orderBy('nombre')->get(['id', 'nombre'])];
    }

    protected function reglas(?int $id = null): array
    {
        return [
            'placa' => 'required|max:15|unique:vehiculos,placa,'.$id, 'marca' => 'nullable|max:255',
            'modelo' => 'nullable|max:255', 'color' => 'nullable|max:30',
            'tipo' => 'required|in:auto,moto,camioneta', 'cliente_id' => 'nullable|exists:clientes,id',
        ];
    }

    protected function preparar(array $datos, $registro = null): array
    {
        $datos['placa'] = strtoupper(trim($datos['placa'])); // placas siempre en mayúscula
        return $datos;
    }
}
