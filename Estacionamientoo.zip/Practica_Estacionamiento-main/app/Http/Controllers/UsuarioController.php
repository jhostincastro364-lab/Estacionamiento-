<?php
namespace App\Http\Controllers;
use App\Models\User;


class UsuarioController extends CrudController
{
    protected string $modelo = User::class;
    protected string $vista = 'usuarios.index';
    protected function reglas(?int $id = null): array
    {
        return [
            'name' => 'required|max:255', 'email' => 'required|email|unique:users,email,'.$id,
            'rol' => 'required|in:administrador,operador,supervisor',
            'password' => ($id ? 'nullable' : 'required').'|min:6',
        ];
    }

    protected function preparar(array $datos, $registro = null): array
    {
        if (empty($datos['password'])) unset($datos['password']);
        return $datos;
    }

    public function estado($id)
    {
        if ((int) $id === auth()->id()) {
            return response()->json(['mensaje' => 'No puedes desactivar tu propio usuario.'], 422);
        }
        return parent::estado($id);
    }
}
