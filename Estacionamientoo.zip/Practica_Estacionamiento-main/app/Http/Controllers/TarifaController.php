<?php
namespace App\Http\Controllers;
use App\Models\Tarifa;

class TarifaController extends CrudController
{
    protected string $modelo = Tarifa::class;
    protected string $vista = 'tarifas.index';
    protected function reglas(?int $id = null): array
    {
        return [
            'tipo_vehiculo' => 'required|in:auto,moto,camioneta|unique:tarifas,tipo_vehiculo,'.$id,
            'precio_hora' => 'required|numeric|min:0', 'fraccion_minutos' => 'required|integer|min:1|max:1440',
        ];
    }
}
