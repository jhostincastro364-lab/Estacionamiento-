<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;

abstract class CrudController extends Controller
{
    protected string $modelo;   // clase del modelo Eloquent
    protected string $vista;    // vista propia del módulo
    abstract protected function reglas(?int $id = null): array; // validaciones
    protected function consulta() { return ($this->modelo)::query(); }
    protected function datosVista(): array { return []; }
    protected function preparar(array $datos, $registro = null): array { return $datos; }
    public function index()
    {
        return view($this->vista, $this->datosVista());
    }

    public function datos()
    {
        return response()->json(['data' => $this->consulta()->orderByDesc('id')->get()]);
    }

    public function store(Request $request)
    {
        $datos = $request->validate($this->reglas());
        ($this->modelo)::create($this->preparar($datos));
        return response()->json(['ok' => true, 'mensaje' => 'Registro creado correctamente.']);
    }

    public function update(Request $request, $id)
    {
        $registro = ($this->modelo)::findOrFail($id);
        $datos = $request->validate($this->reglas($registro->id));
        $registro->update($this->preparar($datos, $registro));
        return response()->json(['ok' => true, 'mensaje' => 'Registro actualizado correctamente.']);
    }

    public function estado($id)
    {
        $registro = ($this->modelo)::findOrFail($id);
        $registro->estado = !$registro->estado;
        $registro->save();
        return response()->json(['ok' => true, 'mensaje' => $registro->estado ? 'Registro activado.' : 'Registro desactivado.']);
    }
}
