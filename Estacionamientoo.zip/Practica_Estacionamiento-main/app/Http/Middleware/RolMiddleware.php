<?php
namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

/**Middleware personalizado de roles.*/
class RolMiddleware
{
    public function handle(Request $request, Closure $next, string ...$roles)
    {
        $usuario = $request->user();

        if (!$usuario || !$usuario->estado || !in_array($usuario->rol, $roles)) {
            abort(403, 'No tienes permiso para acceder a esta sección.');
        }
        return $next($request);
    }
}
