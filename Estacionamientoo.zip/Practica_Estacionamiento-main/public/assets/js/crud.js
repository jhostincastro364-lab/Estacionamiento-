function crudModulo(o) {
  const modal = bootstrap.Modal.getOrCreateInstance(document.querySelector(o.modal));
  const $form = $(o.form);
  const $errores = $form.find('.errores');
  let editandoId = null; // null = creando, número = editando ese registro

  // Aviso pequeño de SweetAlert2
  const aviso = (texto, icono = 'success') =>
    Swal.fire({ toast: true, position: 'top-end', icon: icono, title: texto, showConfirmButton: false, timer: 2200 });

  // Texto del error devuelto por el servidor
  const mensajeError = x => x.responseJSON?.mensaje ?? x.responseJSON?.message ?? 'Ocurrió un error.';

  // Columnas
  const columnas = [
    ...o.columnas,
    { data: 'estado', render: v => v ? '<span class="badge text-bg-success">Activo</span>' : '<span class="badge text-bg-secondary">Inactivo</span>' },
    { data: 'id', orderable: false, searchable: false, render: (id, t, fila) =>
        `<button class="btn btn-sm btn-info btn-editar" title="Editar"><i class="bi bi-pencil"></i></button>
         <button class="btn btn-sm btn-${fila.estado ? 'warning' : 'success'} btn-estado">${fila.estado ? 'Desactivar' : 'Activar'}</button>` },
  ];

  // DataTable 
  const tabla = $(o.tabla).DataTable({
    ajax: o.base + '/datos', columns: columnas, order: [[0, 'desc']],
    language: { url: 'https://cdn.datatables.net/plug-ins/1.13.8/i18n/es-ES.json' },
  });

  $('#btn-nuevo').on('click', function () {
    editandoId = null; $form[0].reset(); $errores.addClass('d-none');
    $(o.modal).find('.modal-title').text('Nuevo ' + o.titulo);
    modal.show();
  });

  $(o.tabla).on('click', '.btn-editar', function () {
    const fila = tabla.row($(this).closest('tr')).data();
    editandoId = fila.id; $form[0].reset(); $errores.addClass('d-none');
    $form.find('[name]').each(function () {
      if (this.type !== 'password') $(this).val(fila[this.name] ?? ''); // la contraseña nunca se rellena
    });
    $(o.modal).find('.modal-title').text('Editar ' + o.titulo);
    modal.show();
  });

  $form.on('submit', function (e) {
    e.preventDefault();
    const url = editandoId ? `${o.base}/${editandoId}` : o.base;
    const datos = $form.serialize() + (editandoId ? '&_method=PUT' : ''); // Laravel simula PUT con _method
    $.post(url, datos)
      .done(r => { modal.hide(); tabla.ajax.reload(null, false); aviso(r.mensaje); }) // recarga solo la tabla
      .fail(x => {
        // 422 = errores de validación: se listan dentro del modal
        const errs = x.status === 422 ? Object.values(x.responseJSON.errors).flat() : [mensajeError(x)];
        $errores.html('<ul class="mb-0">' + errs.map(m => `<li>${m}</li>`).join('') + '</ul>').removeClass('d-none');
      });
  });

  $(o.tabla).on('click', '.btn-estado', function () {
    const fila = tabla.row($(this).closest('tr')).data();
    Swal.fire({ title: '¿Cambiar el estado del registro?', icon: 'question', showCancelButton: true,
                confirmButtonText: 'Sí, cambiar', cancelButtonText: 'Cancelar' }).then(r => {
      if (!r.isConfirmed) return;
      $.post(`${o.base}/${fila.id}/estado`, { _method: 'PATCH' })
        .done(res => { tabla.ajax.reload(null, false); aviso(res.mensaje); })
        .fail(x => Swal.fire('Atención', mensajeError(x), 'warning'));
    });
  });
}
